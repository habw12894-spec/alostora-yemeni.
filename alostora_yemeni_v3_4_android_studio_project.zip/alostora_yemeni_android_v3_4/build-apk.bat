@echo off
REM Run from this folder on a machine with Android Studio/SDK and Gradle installed.
gradle assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK: app\build\outputs\apk\debug\app-debug.apk
