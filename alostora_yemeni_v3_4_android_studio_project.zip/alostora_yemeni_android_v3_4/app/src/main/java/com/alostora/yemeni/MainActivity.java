package com.alostora.yemeni;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.text.InputType;

public class MainActivity extends Activity {
    private static final String PREFS = "alostora_config";
    private static final String SERVER_KEY = "server_url";
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback geoCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,63,45));
        getWindow().setNavigationBarColor(Color.rgb(8,63,45));
        String server = getPreferences(MODE_PRIVATE).getString(SERVER_KEY, "");
        if (server.isEmpty()) showSetup(); else loadApp(server);
    }

    private void showSetup() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(247,250,248));
        TextView title = new TextView(this);
        title.setText("الأسطورة اليمني"); title.setTextSize(28); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(10,104,71)); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));
        TextView desc = new TextView(this);
        desc.setText("أدخل رابط موقع المحفظة المنشور على خادم آمن لربط التطبيق بحسابك. يجب أن يبدأ الرابط بـ https://");
        desc.setTextSize(16); desc.setTextColor(Color.rgb(45,65,55)); desc.setGravity(Gravity.CENTER); desc.setPadding(0, dp(8), 0, dp(24));
        root.addView(desc, new LinearLayout.LayoutParams(-1, -2));
        EditText input = new EditText(this);
        input.setSingleLine(true); input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://wallet.example.com"); input.setTextColor(Color.BLACK); input.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(input, new LinearLayout.LayoutParams(-1, dp(54)));
        Button open = new Button(this); open.setText("اتصال وفتح المحفظة");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54)); bp.topMargin = dp(18); root.addView(open, bp);
        TextView note = new TextView(this);
        note.setText("لا تستخدم رابطًا غير موثوق، ولا تدخل بيانات مالية قبل التأكد من شهادة HTTPS وصحة الموقع."); note.setTextSize(12); note.setTextColor(Color.DKGRAY); note.setPadding(0, dp(22), 0, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        open.setOnClickListener(v -> {
            String url = input.getText().toString().trim();
            if (!url.matches("^https://[^\\s]+$")) { input.setError("أدخل رابط HTTPS صحيحًا"); return; }
            Uri uri = Uri.parse(url);
            if (uri.getHost() == null || uri.getUserInfo() != null) { input.setError("الرابط غير صالح"); return; }
            if (url.endsWith("/")) url = url.substring(0, url.length()-1);
            getPreferences(MODE_PRIVATE).edit().putString(SERVER_KEY, url).apply();
            loadApp(url);
        });
        setContentView(root);
    }

    private void loadApp(String baseUrl) {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String base = getPreferences(MODE_PRIVATE).getString(SERVER_KEY, "");
                if (uri.getScheme().equals("https") && uri.getHost() != null && Uri.parse(base).getHost() != null && uri.getHost().equalsIgnoreCase(Uri.parse(base).getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) callback.invoke(origin, true, false);
                else { pendingGeoOrigin = origin; geoCallback = callback; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 410); }
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, 411); } catch (Exception e) { fileChooserCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.addRequestHeader("User-Agent", userAgent);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                String filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                Toast.makeText(this, "بدأ تنزيل الملف", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "تعذر تنزيل الملف", Toast.LENGTH_LONG).show(); }
        });
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(Color.WHITE);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), 0, dp(8), 0);
        toolbar.setBackgroundColor(Color.rgb(8,63,45));
        Button reload = new Button(this);
        reload.setText("تحديث");
        reload.setTextSize(12);
        Button settings = new Button(this);
        settings.setText("إعدادات الخادم");
        settings.setTextSize(12);
        TextView brand = new TextView(this);
        brand.setText("الأسطورة اليمني");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(16);
        brand.setTypeface(null, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        toolbar.addView(reload, new LinearLayout.LayoutParams(-2, dp(46)));
        toolbar.addView(brand, brandLp);
        toolbar.addView(settings, new LinearLayout.LayoutParams(-2, dp(46)));
        reload.setOnClickListener(v -> webView.reload());
        settings.setOnClickListener(v -> changeServer());
        shell.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(52)));
        shell.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(shell);
        webView.loadUrl(baseUrl + "/");
    }

    private void changeServer() {
        new AlertDialog.Builder(this).setTitle("تغيير رابط المحفظة")
            .setMessage("سيتم مسح ذاكرة ملفات الصفحة داخل التطبيق ثم إدخال رابط جديد. قد تحتاج إلى تسجيل الدخول مرة أخرى.")
            .setNegativeButton("إلغاء", (d,w)->{})
            .setPositiveButton("متابعة", (d,w)->{
                if (webView != null) { webView.clearCache(true); webView.clearHistory(); }
                getPreferences(MODE_PRIVATE).edit().remove(SERVER_KEY).apply();
                showSetup();
            }).show();
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "تغيير رابط الخادم");
        menu.add(0, 2, 1, "إعادة تحميل");
        return true;
    }
    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) { changeServer(); return true; }
        if (item.getItemId() == 2 && webView != null) { webView.reload(); return true; }
        return super.onOptionsItemSelected(item);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 410 && geoCallback != null) {
            boolean granted = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) granted = true;
            geoCallback.invoke(pendingGeoOrigin, granted, false); geoCallback = null; pendingGeoOrigin = null;
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 411 && fileChooserCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileChooserCallback.onReceiveValue(result); fileChooserCallback = null;
        }
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
